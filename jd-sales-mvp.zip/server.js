const express = require('express');
const cookieParser = require('cookie-parser');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const path = require('path');

const app = express();
const db = new Database(process.env.DB_PATH || 'jd_sales.db');
const SECRET = process.env.JWT_SECRET || 'troque-esta-chave-em-producao';
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('admin','backoffice','supervisor','vendedor')),
 supervisor_id INTEGER,
 active INTEGER DEFAULT 1,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS clients (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 cpf TEXT UNIQUE NOT NULL,
 phone TEXT,
 whatsapp TEXT,
 email TEXT,
 cep TEXT,
 address TEXT,
 city TEXT,
 state TEXT,
 notes TEXT,
 created_by INTEGER,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS operators (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT UNIQUE NOT NULL,
 active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS plans (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 operator_id INTEGER,
 name TEXT NOT NULL,
 price REAL DEFAULT 0,
 commission REAL DEFAULT 0,
 active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS statuses (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT UNIQUE NOT NULL,
 color TEXT DEFAULT '#7c3aed',
 active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS sales (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 protocol TEXT UNIQUE,
 client_id INTEGER NOT NULL,
 seller_id INTEGER NOT NULL,
 operator_id INTEGER,
 plan_id INTEGER,
 status_id INTEGER,
 value REAL DEFAULT 0,
 notes TEXT,
 created_by INTEGER,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
 archived INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS audit_log (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER,
 entity TEXT,
 entity_id INTEGER,
 action TEXT,
 details TEXT,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

function seed(){
 const count = db.prepare('SELECT COUNT(*) c FROM users').get().c;
 if(!count){
  const hash=bcrypt.hashSync('admin123',10);
  db.prepare('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)').run('Administrador','admin@jdsales.com',hash,'admin');
 }
 ['Brisanet','Claro','Desktop','Vero','Giga+'].forEach(n=>db.prepare('INSERT OR IGNORE INTO operators(name) VALUES(?)').run(n));
 ['Novo','Viabilidade','Auditoria','Agendado','Instalado','Cancelado','Sem viabilidade'].forEach(n=>db.prepare('INSERT OR IGNORE INTO statuses(name) VALUES(?)').run(n));
}
seed();

function auth(req,res,next){
 const token=req.cookies.token || (req.headers.authorization||'').replace('Bearer ','');
 if(!token) return res.status(401).json({error:'Não autenticado'});
 try{ req.user=jwt.verify(token,SECRET); next(); }catch(e){ res.status(401).json({error:'Sessão inválida'}); }
}
function canSeeSeller(user, sellerId){
 if(['admin','backoffice'].includes(user.role)) return true;
 if(user.role==='vendedor') return Number(sellerId)===Number(user.id);
 if(user.role==='supervisor'){
  const s=db.prepare('SELECT supervisor_id FROM users WHERE id=?').get(sellerId);
  return s && Number(s.supervisor_id)===Number(user.id);
 }
 return false;
}
function log(user, entity, id, action, details=''){
 db.prepare('INSERT INTO audit_log(user_id,entity,entity_id,action,details) VALUES(?,?,?,?,?)').run(user?.id||null,entity,id,action,details);
}

app.post('/api/login',(req,res)=>{
 const {email,password}=req.body;
 const u=db.prepare('SELECT * FROM users WHERE email=? AND active=1').get(email);
 if(!u || !bcrypt.compareSync(password,u.password_hash)) return res.status(401).json({error:'E-mail ou senha inválidos'});
 const payload={id:u.id,name:u.name,email:u.email,role:u.role,supervisor_id:u.supervisor_id};
 res.cookie('token',jwt.sign(payload,SECRET,{expiresIn:'8h'}),{httpOnly:true,sameSite:'lax'}).json(payload);
});
app.post('/api/logout',(req,res)=>res.clearCookie('token').json({ok:true}));
app.get('/api/me',auth,(req,res)=>res.json(req.user));

app.get('/api/dashboard',auth,(req,res)=>{
 let where='archived=0', params=[];
 if(req.user.role==='vendedor'){ where+=' AND seller_id=?'; params.push(req.user.id); }
 if(req.user.role==='supervisor'){ where+=' AND seller_id IN (SELECT id FROM users WHERE supervisor_id=?)'; params.push(req.user.id); }
 const total=db.prepare(`SELECT COUNT(*) c FROM sales WHERE ${where}`).get(...params).c;
 const today=db.prepare(`SELECT COUNT(*) c FROM sales WHERE ${where} AND date(created_at)=date('now')`).get(...params).c;
 const installed=db.prepare(`SELECT COUNT(*) c FROM sales s LEFT JOIN statuses st ON st.id=s.status_id WHERE ${where} AND lower(st.name)='instalado'`).get(...params).c;
 const canceled=db.prepare(`SELECT COUNT(*) c FROM sales s LEFT JOIN statuses st ON st.id=s.status_id WHERE ${where} AND lower(st.name)='cancelado'`).get(...params).c;
 res.json({total,today,installed,canceled});
});

app.get('/api/users',auth,(req,res)=>{
 if(!['admin','backoffice','supervisor'].includes(req.user.role)) return res.status(403).json({error:'Sem permissão'});
 let rows=db.prepare('SELECT id,name,email,role,supervisor_id,active FROM users ORDER BY name').all();
 if(req.user.role==='supervisor') rows=rows.filter(u=>u.supervisor_id===req.user.id || u.id===req.user.id);
 res.json(rows);
});
app.post('/api/users',auth,(req,res)=>{
 if(req.user.role!=='admin') return res.status(403).json({error:'Apenas administrador cria usuários'});
 const {name,email,password,role,supervisor_id}=req.body;
 const hash=bcrypt.hashSync(password||'123456',10);
 const r=db.prepare('INSERT INTO users(name,email,password_hash,role,supervisor_id) VALUES(?,?,?,?,?)').run(name,email,hash,role,supervisor_id||null);
 log(req.user,'user',r.lastInsertRowid,'create',name);
 res.json({id:r.lastInsertRowid});
});

app.get('/api/options',auth,(req,res)=>{
 res.json({operators:db.prepare('SELECT * FROM operators WHERE active=1 ORDER BY name').all(), plans:db.prepare('SELECT * FROM plans WHERE active=1 ORDER BY name').all(), statuses:db.prepare('SELECT * FROM statuses WHERE active=1 ORDER BY id').all(), sellers:db.prepare("SELECT id,name,role,supervisor_id FROM users WHERE active=1 AND role='vendedor' ORDER BY name").all()});
});
app.post('/api/operators',auth,(req,res)=>{ if(req.user.role!=='admin') return res.status(403).json({error:'Sem permissão'}); const r=db.prepare('INSERT OR IGNORE INTO operators(name) VALUES(?)').run(req.body.name); res.json({id:r.lastInsertRowid}); });
app.post('/api/plans',auth,(req,res)=>{ if(req.user.role!=='admin') return res.status(403).json({error:'Sem permissão'}); const r=db.prepare('INSERT INTO plans(operator_id,name,price,commission) VALUES(?,?,?,?)').run(req.body.operator_id,req.body.name,req.body.price||0,req.body.commission||0); res.json({id:r.lastInsertRowid}); });
app.post('/api/statuses',auth,(req,res)=>{ if(req.user.role!=='admin') return res.status(403).json({error:'Sem permissão'}); const r=db.prepare('INSERT OR IGNORE INTO statuses(name,color) VALUES(?,?)').run(req.body.name,req.body.color||'#7c3aed'); res.json({id:r.lastInsertRowid}); });

app.get('/api/sales',auth,(req,res)=>{
 let where='s.archived=0', params=[];
 if(req.user.role==='vendedor'){ where+=' AND s.seller_id=?'; params.push(req.user.id); }
 if(req.user.role==='supervisor'){ where+=' AND s.seller_id IN (SELECT id FROM users WHERE supervisor_id=?)'; params.push(req.user.id); }
 const q=req.query.q;
 if(q){ where+=' AND (c.name LIKE ? OR c.cpf LIKE ? OR c.phone LIKE ? OR s.protocol LIKE ?)'; params.push(`%${q}%`,`%${q}%`,`%${q}%`,`%${q}%`); }
 const rows=db.prepare(`SELECT s.*, c.name client_name,c.cpf,c.phone, u.name seller_name, o.name operator_name, p.name plan_name, st.name status_name
 FROM sales s JOIN clients c ON c.id=s.client_id JOIN users u ON u.id=s.seller_id
 LEFT JOIN operators o ON o.id=s.operator_id LEFT JOIN plans p ON p.id=s.plan_id LEFT JOIN statuses st ON st.id=s.status_id
 WHERE ${where} ORDER BY s.created_at DESC LIMIT 200`).all(...params);
 res.json(rows);
});

app.post('/api/sales',auth,(req,res)=>{
 const {client,seller_id,operator_id,plan_id,status_id,value,notes,allow_duplicate}=req.body;
 const seller = ['admin','backoffice'].includes(req.user.role) ? (seller_id||req.user.id) : req.user.id;
 if(!canSeeSeller(req.user,seller) && req.user.role!=='backoffice') return res.status(403).json({error:'Sem permissão para esse vendedor'});
 const existing=db.prepare('SELECT * FROM clients WHERE cpf=? OR (phone IS NOT NULL AND phone<>"" AND phone=?)').get(client.cpf, client.phone||'');
 if(existing && !allow_duplicate && !['admin','backoffice','supervisor'].includes(req.user.role)) return res.status(409).json({error:'Cliente já cadastrado. Peça liberação ao supervisor.', existing});
 let clientId=existing?.id;
 if(!clientId){
  const r=db.prepare('INSERT INTO clients(name,cpf,phone,whatsapp,email,cep,address,city,state,notes,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
   .run(client.name,client.cpf,client.phone,client.whatsapp,client.email,client.cep,client.address,client.city,client.state,client.notes,req.user.id);
  clientId=r.lastInsertRowid;
 }
 const proto='JDS-'+new Date().getFullYear()+'-'+String(Date.now()).slice(-6);
 const r=db.prepare('INSERT INTO sales(protocol,client_id,seller_id,operator_id,plan_id,status_id,value,notes,created_by) VALUES(?,?,?,?,?,?,?,?,?)')
 .run(proto,clientId,seller,operator_id||null,plan_id||null,status_id||null,value||0,notes||'',req.user.id);
 log(req.user,'sale',r.lastInsertRowid,'create',proto);
 res.json({id:r.lastInsertRowid,protocol:proto});
});

app.put('/api/sales/:id',auth,(req,res)=>{
 const sale=db.prepare('SELECT * FROM sales WHERE id=?').get(req.params.id);
 if(!sale) return res.status(404).json({error:'Venda não encontrada'});
 if(!canSeeSeller(req.user,sale.seller_id)) return res.status(403).json({error:'Sem permissão'});
 if(req.user.role==='vendedor') return res.status(403).json({error:'Vendedor não pode editar venda após criada nesta versão'});
 const {status_id,notes,value}=req.body;
 db.prepare('UPDATE sales SET status_id=COALESCE(?,status_id), notes=COALESCE(?,notes), value=COALESCE(?,value), updated_at=CURRENT_TIMESTAMP WHERE id=?').run(status_id,notes,value,req.params.id);
 log(req.user,'sale',req.params.id,'update',JSON.stringify(req.body));
 res.json({ok:true});
});

app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log('JD Sales rodando na porta '+PORT));
