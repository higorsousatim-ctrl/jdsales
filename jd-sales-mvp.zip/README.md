# JD Sales MVP

Primeira versão funcional do CRM JD Sales.

## Login inicial
- E-mail: admin@jdsales.com
- Senha: admin123

## Rodar localmente
```bash
npm install
npm start
```
Acesse: http://localhost:3000

## Publicar no Render
1. Suba estes arquivos em um repositório no GitHub.
2. No Render, clique em New + > Web Service.
3. Conecte o repositório.
4. Build Command: `npm install`
5. Start Command: `npm start`
6. Clique em Create Web Service.

## O que já tem
- Login
- Perfis: admin, backoffice, supervisor, vendedor
- Cadastro de usuários
- Cadastro de clientes e vendas
- Bloqueio de CPF/telefone duplicado para vendedor
- Vendedor vê somente suas vendas
- Supervisor vê equipe
- Backoffice e Admin veem tudo
- Operadoras, planos e status editáveis pelo Admin
- Dashboard inicial
- Histórico básico de auditoria

## Observação
Este MVP usa SQLite para facilitar o início. Para produção definitiva, migrar para PostgreSQL/Supabase.
